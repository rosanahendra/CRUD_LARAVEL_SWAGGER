<?php

namespace App\Http\Controllers\Candidates;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\CandidateRequest;

use App\Repositories\CandidateRepository;
use App\Repositories\ResponseRepository;
use Illuminate\Http\Response;

class CandidatesController extends Controller
{
    public $candidateRepository;
    public $responseRepository;

    public function __construct(CandidateRepository $candidateRepository, ResponseRepository $rp)
    {
        $this->middleware('auth:api', ['except' => ['indexAll']]);
        $this->candidateRepository = $candidateRepository;
        $this->responseRepository = $rp;
    }

    /**
     * @OA\GET(
     *     path="/api/candidates",
     *     tags={"Candidates"},
     *     summary="Get Candidate List",
     *     description="Get Candidate List as Array",
     *     operationId="index",
     *     @OA\Response(response=200,description="Get Candidate List as Array"),
     *     @OA\Response(response=400, description="Bad request"),
     *     @OA\Response(response=404, description="Resource Not Found"),
     * )
     */
    public function index()
    {
        try {
            $data = $this->candidateRepository->getAll();
            return $this->responseRepository->ResponseSuccess($data, 'Candidate List Fetch Successfully !');
        } catch (\Exception $e) {
            return $this->responseRepository->ResponseError(null, $e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    
    /**
     * @OA\GET(
     *     path="/api/candidates/view/all",
     *     tags={"Candidates"},
     *     summary="All Candidates - Publicly Accessable",
     *     description="All Candidates - Publicly Accessable",
     *     operationId="indexAll",
     *     @OA\Parameter(name="perPage", description="perPage, eg; 20", example=20, in="query", @OA\Schema(type="integer")),
     *     @OA\Response(response=200, description="All Candidates - Publicly Accessable" ),
     *     @OA\Response(response=400, description="Bad request"),
     *     @OA\Response(response=404, description="Resource Not Found"),
     * )
     */
    public function indexAll(Request $request)
    {
        try {
            $data = $this->candidateRepository->getPaginatedData($request->perPage);
            return $this->responseRepository->ResponseSuccess($data, 'Candidate List Fetched Successfully !');
        } catch (\Exception $e) {
            return $this->responseRepository->ResponseError(null, $e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * @OA\GET(
     *     path="/api/candidates/view/search",
     *     tags={"Candidates"},
     *     summary="All Candidates - Publicly Accessable",
     *     description="All Candidates - Publicly Accessable",
     *     operationId="search",
     *     @OA\Parameter(name="perPage", description="perPage, eg; 20", example=20, in="query", @OA\Schema(type="integer")),
     *     @OA\Parameter(name="search", description="search, eg; Test", example="Test", in="query", @OA\Schema(type="string")),
     *     @OA\Response(response=200, description="All Candidates - Publicly Accessable" ),
     *     @OA\Response(response=400, description="Bad request"),
     *     @OA\Response(response=404, description="Resource Not Found"),
     * )
     */
    public function search(Request $request)
    {
        try {
            $data = $this->candidateRepository->searchCandidate($request->search, $request->perPage);
            return $this->responseRepository->ResponseSuccess($data, 'Candidate List Fetched Successfully !');
        } catch (\Exception $e) {
            return $this->responseRepository->ResponseError(null, $e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @OA\POST(
     *     path="/api/candidates",
     *     tags={"Candidates"},
     *     summary="Create New Candidate",
     *     description="Create New Candidate",
     *     operationId="store",
     *     @OA\RequestBody(
     *          @OA\JsonContent(
     *              type="object",
     *              @OA\Property(property="cand_name", type="string", example=""),
     *              @OA\Property(property="cand_education", type="string", example=""),
     *              @OA\Property(property="cand_birthday", type="string", example=""),
     *              @OA\Property(property="cand_experience", type="string", example=""),
     *              @OA\Property(property="cand_last_position", type="string", example=""),
     *              @OA\Property(property="cand_applied_position", type="string", example=""),
     *              @OA\Property(property="cand_skill", type="string", example=""),
     *              @OA\Property(property="cand_phone", type="string", example=""),
     *              @OA\Property(property="cand_email", type="string", example=""),
     *              @OA\Property(property="cand_resume", type="string", example=""),
     *          ),
     *      ),
     *      @OA\Response(response=200, description="Create New Candidate" ),
     *      @OA\Response(response=400, description="Bad request"),
     *      @OA\Response(response=404, description="Resource Not Found"),
     * )
     */
	 
    public function store(CandidateRequest $request)
    {
        try {
            $data = $request->all();
            $unit = $this->candidateRepository->create($data);
            return $this->responseRepository->ResponseSuccess($unit, 'New Candidate Created Successfully !');
        } catch (\Exception $exception) {
            return $this->responseRepository->ResponseError(null, $exception->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @OA\GET(
     *     path="/api/candidates/{id}",
     *     tags={"Candidates"},
     *     summary="Show Candidate Details",
     *     description="Show Candidate Details",
     *     operationId="show",
     *     @OA\Parameter(name="id", description="id, eg; 1", required=true, in="path", @OA\Schema(type="integer")),
     *     @OA\Response(response=200, description="Show Candidate Details" ),
     *     @OA\Response(response=400, description="Bad request"),
     *     @OA\Response(response=404, description="Resource Not Found"),
     * )
     */
    public function show($id)
    {
        try {
            $data = $this->candidateRepository->getByID($id);
            if(is_null($data))
                return $this->responseRepository->ResponseError(null, 'Candidate Not Found', Response::HTTP_NOT_FOUND);

            return $this->responseRepository->ResponseSuccess($data, 'Candidate Details Fetch Successfully !');
        } catch (\Exception $e) {
            return $this->responseRepository->ResponseError(null, $e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @OA\PUT(
     *     path="/api/candidates/{id}",
     *     tags={"Candidates"},
     *     summary="Update Candidate",
     *     description="Update Candidate",
     *     @OA\Parameter(name="id", description="id, eg; 1", required=true, in="path", @OA\Schema(type="integer")),
     *     @OA\RequestBody(
     *          @OA\JsonContent(
     *              type="object",
	 *              @OA\Property(property="cand_name", type="string", example=""),
     *              @OA\Property(property="cand_education", type="string", example=""),
     *              @OA\Property(property="cand_birthday", type="string", example=""),
     *              @OA\Property(property="cand_experience", type="string", example=""),
     *              @OA\Property(property="cand_last_position", type="string", example=""),
     *              @OA\Property(property="cand_applied_position", type="string", example=""),
     *              @OA\Property(property="cand_skill", type="string", example=""),
     *              @OA\Property(property="cand_phone", type="string", example=""),
     *              @OA\Property(property="cand_email", type="string", example=""),
     *          ),
     *      ),
     *     operationId="update",
     *     @OA\Response( response=200, description="Update Candidate" ),
     *     @OA\Response(response=400, description="Bad request"),
     *     @OA\Response(response=404, description="Resource Not Found"),
     * )
     */
    public function update(CandidateRequest $request, $id)
    {
        try {
            $data = $this->candidateRepository->update($id, $request->all());
            if(is_null($data))
                return $this->responseRepository->ResponseError(null, 'Candidate Not Found', Response::HTTP_NOT_FOUND);

            return $this->responseRepository->ResponseSuccess($data, 'Candidate Updated Successfully !');
        } catch (\Exception $e) {
            return $this->responseRepository->ResponseError(null, $e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @OA\DELETE(
     *     path="/api/candidates/{id}",
     *     tags={"Candidates"},
     *     summary="Delete Candidate",
     *     description="Delete Candidate",
     *     operationId="destroy",
     *     @OA\Parameter(name="id", description="id, eg; 1", required=true, in="path", @OA\Schema(type="integer")),
     *     @OA\Response( response=200, description="Delete Candidate" ),
     *     @OA\Response(response=400, description="Bad request"),
     *     @OA\Response(response=404, description="Resource Not Found"),
     * )
     */
    public function destroy($id)
    {
        try {
            $produtData =  $this->candidateRepository->getByID($id);
            $deleted = $this->candidateRepository->delete($id);
            if(!$deleted)
                return $this->responseRepository->ResponseError(null, 'Candidate Not Found', Response::HTTP_NOT_FOUND);

            return $this->responseRepository->ResponseSuccess($produtData, 'Candidate Deleted Successfully !');
        } catch (\Exception $e) {
            return $this->responseRepository->ResponseError(null, $e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
