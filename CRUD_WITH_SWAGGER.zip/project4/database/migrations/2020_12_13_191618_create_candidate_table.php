<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCandidateTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('candidate', function (Blueprint $table) {
            $table->id();
            $table->string('cand_name', 255);
            $table->text('cand_education')->nullable();
            $table->text('cand_birthday')->nullable();
            $table->text('cand_experience')->nullable();
            $table->text('cand_last_position')->nullable();
            $table->text('cand_applied_position')->nullable();
            $table->text('cand_skill')->nullable();
            $table->text('cand_phone')->nullable();
            $table->text('cand_email')->nullable();
            $table->string('cand_resume')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('candidate');
    }
}
